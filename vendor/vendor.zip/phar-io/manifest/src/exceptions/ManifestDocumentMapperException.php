<?php declare(strict_types = 1);
namespace PharIo\Manifest;

class ManifestDocumentMapperException extends \RuntimeException implements Exception {
}
